from django.apps import AppConfig


class MyenConfig(AppConfig):
    name = 'myen'
