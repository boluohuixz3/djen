cc="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
a=","
if a in cc :
    print(1)
else:
    print(0)

a="ABbbC"
a=a.lower()
print(a)

